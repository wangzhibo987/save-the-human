﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Windows.Threading;
namespace save_the_human
{
    /// <summary>
    /// MainPage.xaml 的交互逻辑
    /// </summary>
    public partial class MainPage : Page
    {
        Random random = new Random();
        DispatcherTimer enemyTimer = new DispatcherTimer();
        DispatcherTimer targetTimer = new DispatcherTimer();
        bool humanCaptured = false;


        public MainPage()
        {
            InitializeComponent();

            enemyTimer.Tick += EnemyTimer_Tick;
            enemyTimer.Interval = TimeSpan.FromSeconds(2);

            targetTimer.Tick += TargetTimer_Tick;
            targetTimer.Interval = TimeSpan.FromSeconds(.1);
        }

        private void TargetTimer_Tick(object sender, EventArgs e)
        {
            ProgressBar.Value += 1;
            if(ProgressBar.Value >= ProgressBar.Maximum)
            {
                EndTheGame();
            }
        }

        private void EndTheGame()
        {
            if (!playArea.Children.Contains(gameOverText))
            {

                enemyTimer.Stop();
                targetTimer.Stop();
                humanCaptured = false;
                startButton.Visibility = Visibility.Visible;
                playArea.Children.Add(gameOverText);

            }
        }

        private void EnemyTimer_Tick(object sender, EventArgs e)
        {


            AddEnemy();

        }

        private void AddEnemy()
        {

                ContentControl enemy = new ContentControl();
                enemy.Template = Resources["EnemyTemplate2"] as ControlTemplate;
                AnimateEnemy(enemy, 0, playArea.ActualWidth - 100, "(Canvas.Left)");
                AnimateEnemy(enemy, random.Next((int)playArea.ActualHeight - 100), 
                random.Next((int)playArea.ActualHeight - 100), "(Canvas.Top)");
                playArea.Children.Add(enemy);
            enemy.MouseEnter += Enemy_MouseEnter;
                
            /*
            // 创建新的敌人
            ContentControl enemy = new ContentControl();
            enemy.Template = Resources["EnemyTemplate2"] as ControlTemplate;

            // 动画敌人的左右移动
            double startLeft = random.Next((int)(playArea.ActualWidth - 100));
            AnimateEnemy(enemy, startLeft, playArea.ActualWidth - 100, "(Canvas.Left)");

            // 动画敌人的上下移动
            double startTop = random.Next((int)(playArea.ActualHeight - 100));
            AnimateEnemy(enemy, startTop, playArea.ActualHeight - 100, "(Canvas.Top)");

            // 将敌人添加到游戏区域
            playArea.Children.Add(enemy);
            */
        }

        private void Enemy_MouseEnter(object sender, MouseEventArgs e)
        {
            if (humanCaptured)
            {
                EndTheGame();
            }
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            StartGame();
              
            
                /*ContentControl enemy = new ContentControl();
                enemy.Template = Resources["EnemyTemplate2"] as ControlTemplate;
                AnimateEnemy(enemy, 0, playArea.ActualWidth - 100, "(Canvas.Left)");
                AnimateEnemy(enemy, random.Next((int)playArea.ActualHeight - 100), 
                random.Next((int)playArea.ActualHeight - 100), "(Canvas.Top)");
                playArea.Children.Add(enemy);
                */
            
        }

        private void StartGame()
        {
            human.IsHitTestVisible = true;
            humanCaptured = false;
            ProgressBar.Value = 0;
            startButton.Visibility = Visibility.Collapsed;
            playArea.Children.Clear();
            // 确保 target 和 human 先从其父容器中移除
            if (target.Parent != null)
            {
                var parent = target.Parent as Panel;
                parent.Children.Remove(target);
            }

            if (human.Parent != null)
            {
                var parent = human.Parent as Panel;
                parent.Children.Remove(human);
            }
            playArea.Children.Add(target);
            playArea.Children.Add(human);
            enemyTimer.Start();
            targetTimer.Start();
        }

        private void AnimateEnemy(ContentControl enemy, double from, double to, string propertyToAnimate)
        {
            Storyboard storyboard = new Storyboard() { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever };
            DoubleAnimation animation = new DoubleAnimation()
            {
                From = from,
                To = to,
                Duration = new Duration(TimeSpan.FromSeconds(random.Next(4, 6)))
        };
            
            Storyboard.SetTarget(animation, enemy);
            Storyboard.SetTargetProperty(animation, new PropertyPath(propertyToAnimate));
            storyboard.Children.Add(animation);
            storyboard.Begin();

            
        }

        private void human_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (enemyTimer.IsEnabled)
            {
                humanCaptured = true;
                human.IsHitTestVisible = false;
            }
        }

        private void target_MouseEnter(object sender, MouseEventArgs e)
        {
            if(targetTimer.IsEnabled && humanCaptured)
            {
                ProgressBar.Value = 0;
                Canvas.SetLeft(target, random.Next(100, (int)playArea.ActualWidth - 100));
                Canvas.SetTop(target, random.Next(100, (int)playArea.ActualHeight - 100));
                Canvas.SetLeft(human, random.Next(100, (int)playArea.ActualWidth - 100));
                Canvas.SetTop(human, random.Next(100, (int)playArea.ActualHeight - 100));
                humanCaptured = false;
                human.IsHitTestVisible = true;
            }
        }

        private void grid_MouseMove(object sender, MouseEventArgs e)
        {
            if (humanCaptured)
            {
                Point pointerposition = e.GetPosition(null);
                Point relativePosition = grid.TransformToVisual(playArea).Transform(pointerposition);
                if((Math.Abs(relativePosition.X - Canvas.GetLeft(human)) > human.ActualWidth *3 ) || (Math.Abs(relativePosition.Y - Canvas.GetTop(human)) > human.ActualHeight * 3))
                {
                    humanCaptured = false;
                    human.IsHitTestVisible = true;

                }
                else
                {
                    Canvas.SetLeft(human, relativePosition.X - human.ActualWidth / 2);
                    Canvas.SetTop(human, relativePosition.Y - human.ActualHeight / 2);

                }
            }
        }

        private void grid_MouseLeave(object sender, MouseEventArgs e)
        {
            if (humanCaptured)
            {
                EndTheGame();
            }
        }
    }
}
